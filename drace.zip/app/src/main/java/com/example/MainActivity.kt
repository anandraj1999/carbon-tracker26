package com.example

import android.content.Context
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import org.json.JSONArray
import org.json.JSONObject
import java.net.ServerSocket
import java.net.Socket
import java.io.OutputStream
import java.net.NetworkInterface
import java.net.URLDecoder
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

// Room-related structures
data class Player(
    val id: String,
    var name: String,
    var x: Float = 0f,
    var y: Float = 0f,
    var z: Float = 0f,
    var rot: Float = 0f,
    var progress: Float = 0f,
    var speed: Float = 0f,
    var color: String = "#ffffff",
    var active: Boolean = true,
    val isBot: Boolean = false,
    var lastUpdate: Long = System.currentTimeMillis()
)

data class Room(
    val code: String,
    val track: String = "Neon Circuit",
    val players: MutableList<Player> = mutableListOf(),
    var gameStarted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

class MainActivity : ComponentActivity() {
    private var httpServer: TinyHttpServer? = null
    private val serverPort = 9000
    private var serverIp = "127.0.0.1"

    companion object {
        val rooms = ConcurrentHashMap<String, Room>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Start the local background full-stack room manager
        startServer()
        serverIp = getLocalIpAddress(this)

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    GameScreen(serverIp = serverIp, port = serverPort)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopServer()
    }

    private fun startServer() {
        try {
            httpServer = TinyHttpServer(serverPort, this)
            httpServer?.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopServer() {
        try {
            httpServer?.stop()
            httpServer = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

// Global Help to parse query parameters safely
fun parseQueryParams(query: String?): Map<String, String> {
    val result = mutableMapOf<String, String>()
    if (query == null) return result
    val pairs = query.split("&")
    for (pair in pairs) {
        val idx = pair.indexOf("=")
        if (idx > 0) {
            val key = URLDecoder.decode(pair.substring(0, idx), "UTF-8")
            val value = URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
            result[key] = value
        }
    }
    return result
}

fun generateRoomCode(): String {
    val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    val random = Random()
    return (1..6).map { chars[random.nextInt(chars.length)] }.joinToString("")
}

fun getPlayersJsonArray(players: List<Player>): JSONArray {
    val arr = JSONArray()
    for (p in players) {
        val obj = JSONObject().apply {
            put("id", p.id)
            put("name", p.name)
            put("x", p.x)
            put("y", p.y)
            put("z", p.z)
            put("rot", p.rot)
            put("progress", p.progress)
            put("speed", p.speed)
            put("color", p.color)
            put("isBot", p.isBot)
            put("active", p.active)
        }
        arr.put(obj)
    }
    return arr
}

class TinyHttpServer(private val port: Int, private val context: Context) {
    private var serverSocket: ServerSocket? = null
    private val executor = Executors.newCachedThreadPool()
    @Volatile private var isRunning = false

    fun start() {
        isRunning = true
        executor.execute {
            try {
                serverSocket = ServerSocket(port)
                while (isRunning) {
                    val socket = serverSocket?.accept() ?: break
                    executor.execute { handleClient(socket) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        executor.shutdown()
    }

    private fun handleClient(socket: Socket) {
        try {
            val reader = socket.getInputStream().bufferedReader(Charsets.UTF_8)
            val requestLine = reader.readLine()
            if (requestLine.isNullOrEmpty()) {
                socket.close()
                return
            }

            val parts = requestLine.split(" ")
            if (parts.size < 2) {
                socket.close()
                return
            }

            val method = parts[0]
            val fullPath = parts[1]

            // Read headers until blank line
            var line: String? = reader.readLine()
            while (!line.isNullOrEmpty()) {
                line = reader.readLine()
            }

            val queryIdx = fullPath.indexOf('?')
            val path = if (queryIdx >= 0) fullPath.substring(0, queryIdx) else fullPath
            val query = if (queryIdx >= 0) fullPath.substring(queryIdx + 1) else null

            val out = socket.getOutputStream()

            if (method.equals("OPTIONS", true)) {
                sendResponse(out, 204, "No Content", "application/json", ByteArray(0), cors = true)
                return
            }

            when (path) {
                "/" -> serveMain(out)
                "/index.html" -> serveMain(out)
                "/api/create" -> handleCreateRoom(out, query)
                "/api/join" -> handleJoinRoom(out, query)
                "/api/sync" -> handleSyncRoom(out, query)
                "/api/rooms" -> handleRoomsList(out)
                else -> sendResponse(out, 404, "Not Found", "text/plain", "Not Found".toByteArray(), cors = true)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                socket.close()
            } catch (ex: Exception) {}
        }
    }

    private fun serveMain(out: OutputStream) {
        try {
            val content = context.assets.open("index.html").bufferedReader().use { it.readText() }
            val bytes = content.toByteArray(Charsets.UTF_8)
            sendResponse(out, 200, "OK", "text/html; charset=utf-8", bytes, cors = false)
        } catch (e: Exception) {
            val errBytes = "Error loading assets: ${e.message}".toByteArray(Charsets.UTF_8)
            sendResponse(out, 500, "Internal Server Error", "text/plain", errBytes, cors = false)
        }
    }

    private fun handleCreateRoom(out: OutputStream, query: String?) {
        try {
            val params = parseQueryParams(query)
            val creatorName = params["playerName"] ?: "Player 1"
            val carColor = params["color"] ?: "#ff007f"
            val track = params["track"] ?: "Neon Circuit"

            var code = generateRoomCode()
            while (MainActivity.rooms.containsKey(code)) {
                code = generateRoomCode()
            }

            val room = Room(code = code, track = track)
            val creator = Player(
                id = UUID.randomUUID().toString(),
                name = creatorName,
                color = carColor,
                isBot = false,
                lastUpdate = System.currentTimeMillis()
            )
            room.players.add(creator)

            // Spawn 3 matching AI Drivers so multiplayer rooms are instantly competitive!
            room.players.add(Player(id = "bot1", name = "CYBER_VIPER", color = "#00f0ff", speed = 40f, isBot = true, progress = 0.05f))
            room.players.add(Player(id = "bot2", name = "NEON_VIPER", color = "#ffea00", speed = 42f, isBot = true, progress = 0.12f))
            room.players.add(Player(id = "bot3", name = "PLASMA_X", color = "#ff00ea", speed = 39f, isBot = true, progress = 0.18f))

            MainActivity.rooms[code] = room

            val responseObj = JSONObject().apply {
                put("roomCode", code)
                put("playerId", creator.id)
                put("track", room.track)
                put("players", getPlayersJsonArray(room.players))
            }

            val bytes = responseObj.toString().toByteArray(Charsets.UTF_8)
            sendResponse(out, 200, "OK", "application/json; charset=utf-8", bytes, cors = true)
        } catch (e: Exception) {
            val errBytes = "{\"error\": \"${e.message}\"}".toByteArray(Charsets.UTF_8)
            sendResponse(out, 500, "Internal Server Error", "application/json", errBytes, cors = true)
        }
    }

    private fun handleJoinRoom(out: OutputStream, query: String?) {
        try {
            val params = parseQueryParams(query)
            val code = (params["roomCode"] ?: "").trim().uppercase()
            val name = params["playerName"] ?: "Racer"
            val color = params["color"] ?: "#39ff14"

            val room = MainActivity.rooms[code]
            if (room == null) {
                val errBytes = "{\"error\": \"Room not found\"}".toByteArray(Charsets.UTF_8)
                sendResponse(out, 404, "Not Found", "application/json", errBytes, cors = true)
                return
            }

            val player = Player(
                id = UUID.randomUUID().toString(),
                name = name,
                color = color,
                isBot = false,
                lastUpdate = System.currentTimeMillis()
            )
            room.players.add(player)

            val responseObj = JSONObject().apply {
                put("roomCode", code)
                put("playerId", player.id)
                put("track", room.track)
                put("players", getPlayersJsonArray(room.players))
            }

            val bytes = responseObj.toString().toByteArray(Charsets.UTF_8)
            sendResponse(out, 200, "OK", "application/json; charset=utf-8", bytes, cors = true)
        } catch (e: Exception) {
            val errBytes = "{\"error\": \"${e.message}\"}".toByteArray(Charsets.UTF_8)
            sendResponse(out, 500, "Internal Server Error", "application/json", errBytes, cors = true)
        }
    }

    private fun handleSyncRoom(out: OutputStream, query: String?) {
        try {
            val params = parseQueryParams(query)
            val code = (params["roomCode"] ?: "").trim().uppercase()
            val playerId = params["playerId"] ?: ""

            val room = MainActivity.rooms[code]
            if (room == null) {
                val errBytes = "{\"error\": \"Room $code not found\"}".toByteArray(Charsets.UTF_8)
                sendResponse(out, 404, "Not Found", "application/json", errBytes, cors = true)
                return
            }

            val playerObj = room.players.find { it.id == playerId }
            if (playerObj != null) {
                playerObj.x = params["x"]?.toFloatOrNull() ?: playerObj.x
                playerObj.y = params["y"]?.toFloatOrNull() ?: playerObj.y
                playerObj.z = params["z"]?.toFloatOrNull() ?: playerObj.z
                playerObj.rot = params["rot"]?.toFloatOrNull() ?: playerObj.rot
                playerObj.progress = params["progress"]?.toFloatOrNull() ?: playerObj.progress
                playerObj.speed = params["speed"]?.toFloatOrNull() ?: playerObj.speed
                playerObj.lastUpdate = System.currentTimeMillis()
                playerObj.active = true
            }

            // Sync simulation calculations for AI Bots
            updateBotsInRoom(room)

            // Auto-clean inactive human competitors (longer timeout: 15s)
            val timeout = 15000L
            val currentTime = System.currentTimeMillis()
            room.players.iterator().let { iterator ->
                while (iterator.hasNext()) {
                    val p = iterator.next()
                    if (!p.isBot && currentTime - p.lastUpdate > timeout) {
                        iterator.remove()
                    }
                }
            }

            val responseObj = JSONObject().apply {
                put("roomCode", code)
                put("players", getPlayersJsonArray(room.players))
                put("gameStarted", room.gameStarted)
            }

            val bytes = responseObj.toString().toByteArray(Charsets.UTF_8)
            sendResponse(out, 200, "OK", "application/json; charset=utf-8", bytes, cors = true)
        } catch (e: Exception) {
            val errBytes = "{\"error\": \"${e.message}\"}".toByteArray(Charsets.UTF_8)
            sendResponse(out, 500, "Internal Server Error", "application/json", errBytes, cors = true)
        }
    }

    private fun updateBotsInRoom(room: Room) {
        val currentTime = System.currentTimeMillis()
        for (p in room.players) {
            if (p.isBot) {
                val elapsedSec = (currentTime - p.lastUpdate) / 1000.0f
                var progressDelta = elapsedSec * (p.speed / 500.0f)
                if (progressDelta <= 0f || progressDelta > 0.05f) {
                    progressDelta = 0.001f
                }
                var activeProgress = p.progress + progressDelta
                if (activeProgress > 1.0f) activeProgress -= 1.0f
                p.progress = activeProgress
                p.lastUpdate = currentTime

                // Generate circular-clover mathematical track spline:
                // Perfectly matches client's custom Three.js road geometry
                val angle = activeProgress * 2.0f * kotlin.math.PI.toFloat()
                val r = 220f + 65f * kotlin.math.cos(angle * 3.0f)
                p.x = r * kotlin.math.sin(angle)
                p.z = r * kotlin.math.cos(angle)
                p.y = 1.0f + 12f * kotlin.math.sin(angle * 4.0f)

                // Facing direction
                val nextAngle = (activeProgress + 0.001f) * 2.0f * kotlin.math.PI.toFloat()
                val nextR = 220f + 65f * kotlin.math.cos(nextAngle * 3.0f)
                val nextX = nextR * kotlin.math.sin(nextAngle)
                val nextZ = nextR * kotlin.math.cos(nextAngle)
                p.rot = kotlin.math.atan2((nextX - p.x), (nextZ - p.z))
            }
        }
    }

    private fun handleRoomsList(out: OutputStream) {
        try {
            val arr = JSONArray()
            for ((code, r) in MainActivity.rooms) {
                val obj = JSONObject().apply {
                    put("code", code)
                    put("track", r.track)
                    put("activePlayers", r.players.filter { !it.isBot }.size)
                    put("totalPlayers", r.players.size)
                }
                arr.put(obj)
            }
            val bytes = arr.toString().toByteArray(Charsets.UTF_8)
            sendResponse(out, 200, "OK", "application/json; charset=utf-8", bytes, cors = true)
        } catch (e: Exception) {
            val errBytes = "{\"error\": \"${e.message}\"}".toByteArray(Charsets.UTF_8)
            sendResponse(out, 500, "Internal Server Error", "application/json", errBytes, cors = true)
        }
    }

    private fun sendResponse(
        out: OutputStream,
        statusCode: Int,
        statusText: String,
        contentType: String,
        body: ByteArray,
        cors: Boolean
    ) {
        val writer = out.writer(Charsets.UTF_8)
        writer.write("HTTP/1.1 $statusCode $statusText\r\n")
        writer.write("Content-Type: $contentType\r\n")
        writer.write("Content-Length: ${body.size}\r\n")
        writer.write("Connection: close\r\n")
        if (cors) {
            writer.write("Access-Control-Allow-Origin: *\r\n")
            writer.write("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
            writer.write("Access-Control-Allow-Headers: Content-Type\r\n")
        }
        writer.write("\r\n")
        writer.flush()
        out.write(body)
        out.flush()
    }
}

fun getLocalIpAddress(context: Context): String {
    try {
        val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
        for (networkInterface in interfaces) {
            val addresses = Collections.list(networkInterface.inetAddresses)
            for (address in addresses) {
                if (!address.isLoopbackAddress) {
                    val ip = address.hostAddress ?: ""
                    val isIPv4 = ip.indexOf(':') < 0
                    if (isIPv4) {
                        if (ip.startsWith("192.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return "127.0.0.1"
}

@Composable
fun GameScreen(serverIp: String, port: Int) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    layoutParams = android.view.ViewGroup.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        loadWithOverviewMode = true
                        useWideViewPort = true
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                        }
                    }
                    loadUrl("http://localhost:$port/")
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Sleek overlay card indicating IP address
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0x33000000)),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(Color(0xFF39FF14), shape = CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "DRACE SERVER: $serverIp:$port",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White
                )
            }
        }
    }
}

